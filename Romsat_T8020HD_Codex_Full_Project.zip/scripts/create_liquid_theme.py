#!/usr/bin/env python3
"""Create a non-flashable preview / overlay theme for the ROMSAT T8020HD."""
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
import struct, math, shutil, re, zipfile, hashlib
BASE=Path(__file__).parent
SRC=BASE/'extracted/cramfs/dvb/theme'
OUT=BASE/'liquid_glass_theme'
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()
ICONS=SRC/'image/image_T2/mainmenu'
BUTTON=SRC/'image/image_T2/BUTTON'
DO=OUT/'dvb/theme/image/image_T2/mainmenu'
BO=OUT/'dvb/theme/image/image_T2/BUTTON'
DO.mkdir(parents=True); BO.mkdir(parents=True)
CO=OUT/'dvb/theme/color';CO.mkdir(parents=True)
WIDGET=OUT/'dvb/theme/widget';WIDGET.mkdir(parents=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
NAMES={'program':'Телевидение','pic':'Изображение','search':'Поиск','time':'Время','option':'Интернет','system':'Настройки','usb':'USB'}

# Edit RGB565 pixel data inside the original vendor BMP containers.
# This preserves exact header, masks, dimensions and file size.
def output_vendor_bmp(template, dest, image):
 template=Path(template)
 raw=bytearray(template.read_bytes())
 pixel_off=struct.unpack_from('<I',raw,10)[0]
 w,h=struct.unpack_from('<ii',raw,18)
 assert image.size==(w,abs(h)) and struct.unpack_from('<H',raw,28)[0]==16
 assert struct.unpack_from('<I',raw,30)[0]==3 # BI_BITFIELDS
 assert tuple(struct.unpack_from('<III',raw,54))==(0xf800,0x7e0,0x1f)
 stride=((w*2+3)//4)*4
 rgb=image.convert('RGB')
 pixels=rgb.load()
 for y in range(abs(h)):
  real_y = abs(h)-1-y if h>0 else y
  for x in range(w):
   r,g,b=pixels[x,real_y]
   val=((r>>3)<<11)|((g>>2)<<5)|(b>>3)
   struct.pack_into('<H',raw,pixel_off+y*stride+x*2,val)
 dest.write_bytes(raw)
 assert Image.open(dest).size==(w,abs(h))
 assert len(raw)==template.stat().st_size

S=3

def scaled_draw(n,focus):
 w,h=112,137
 im=Image.new('RGB',(w*S,h*S),(14,19,32))
 d=ImageDraw.Draw(im)
 def rr(x0,y0,x1,y1,r,fill,outline=None,width=1):
  d.rounded_rectangle((x0*S,y0*S,x1*S,y1*S),radius=r*S,fill=fill,outline=outline,width=width*S)
 def line(xy,color,width=3,joint='curve'):
  d.line([(int(x*S),int(y*S)) for x,y in xy], fill=color, width=width*S,joint=joint)
 def ellipse(box,outline=None,fill=None,width=2):
  d.ellipse(tuple(v*S for v in box),outline=outline,fill=fill,width=width*S)
 # neutral painted base: no runtime transparency assumed
 for y in range(h*S):
  t=y/(h*S)
  c=tuple(int(x*(1-t)+z*t) for x,z in zip((14,18,31),(19,28,47)))
  d.line((0,y,w*S,y),fill=c)
 rr(7,9,105,124,21,(27,38,58),outline=(67,82,105) if not focus else (121,210,248),width=1)
 rr(11,13,101,120,18,(31,44,64) if not focus else (36,62,83))
 # upper reflected glass sheen
 rr(16,17,96,49,15,(46,60,79) if not focus else (53,91,113))
 d.rectangle((16*S,35*S,96*S,49*S),fill=(31,44,64) if not focus else (36,62,83))
 col=(223,238,248) if not focus else (154,232,255)
 shadow=(80,104,132)
 if n=='program':
  rr(29,51,83,87,6,None,col,3);line([(56,87),(56,94)],col,3);line([(43,95),(69,95)],col,3)
  d.line((34*S,80*S,78*S,80*S),fill=(65,96,115),width=1*S)
 if n=='pic':
  rr(28,48,84,93,7,None,col,3);ellipse((38,55,48,65),fill=col)
  d.polygon([(34*S,86*S),(48*S,69*S),(58*S,81*S),(67*S,71*S),(79*S,88*S)],fill=col)
 if n=='search':
  ellipse((34,48,70,84),outline=col,width=5);line([(65,80),(81,98)],col,5)
 if n=='time':
  ellipse((28,45,84,101),outline=col,width=4);line([(56,58),(56,74),(45,82)],col,4)
 if n=='option':
  ellipse((28,45,84,101),outline=col,width=3)
  ellipse((42,45,70,101),outline=col,width=2)
  line([(29,73),(83,73)],col,2)
  line([(35,57),(77,57)],col,2)
  line([(35,89),(77,89)],col,2)
 if n=='system':
  cx,cy=56,74
  pts=[]
  for i in range(24):
   angle=-math.pi/2+i*math.pi/12
   r=28 if i%3!=1 else 22
   pts.append(((cx+r*math.cos(angle))*S,(cy+r*math.sin(angle))*S))
  d.polygon(pts,fill=col)
  ellipse((43,61,69,87),fill=(31,44,64) if not focus else (36,62,83))
  ellipse((49,67,63,81),fill=col)
 if n=='usb':
  line([(56,94),(56,59)],col,4);line([(56,71),(42,60),(42,52)],col,3);line([(56,80),(72,66),(72,55)],col,3)
  d.polygon([(72*S,47*S),(66*S,56*S),(78*S,56*S)],fill=col)
  rr(39,48,45,54,1,col);ellipse((51,91,61,101),fill=col)
 if focus:
  rr(15,112,97,116,2,(126,220,249))
 else:
  rr(15,112,97,114,1,(75,91,115))
 return im.resize((w,h),Image.Resampling.LANCZOS)

for key in NAMES:
 for state in ['focus','unfocus']:
  src=ICONS/f'T2_icon_{key}_{state}.bmp'
  output_vendor_bmp(src,DO/src.name,scaled_draw(key,state=='focus'))

# Build a glass-blue selection strip, match the vendor's 800x37 RGB565 bitmap.
def focus_strip():
 im=Image.new('RGB',(800,37))
 d=ImageDraw.Draw(im)
 for y in range(37):
  t=y/36
  c=(int(36-10*t),int(77-15*t),int(102-10*t))
  d.line((0,y,799,y),fill=c)
 d.rounded_rectangle((1,1,798,35),radius=13,outline=(96,185,223),width=2)
 d.rounded_rectangle((8,4,789,9),radius=3,fill=(62,113,144))
 return im
focus_template=BUTTON/'T2_button_blue1000.bmp'
output_vendor_bmp(focus_template,BO/'T2_button_blue1000.bmp',focus_strip())

# Changes deliberately limited to existing color keys, without changing object names or coordinates.
color_src=(SRC/'color/color.xml').read_text(encoding='utf-8')
replace={'text_focus_color':'#FFFFFF','text_tag_color':'#9AD8F7','text_golden_color':'#91DFFB',
         'window_bg_color':'#111C2D','window_top_color':'#111C2D','window_bot_color':'#111C2D',
         'default_color':'#64758F'}
for key,hexval in replace.items():
 pattern=r'(<color\s+name="'+re.escape(key)+r'"\s*>\s*)#[0-9A-Fa-f]{6}(\s*</color>)'
 color_src,n=re.subn(pattern,lambda m:m.group(1)+hexval+m.group(2),color_src,count=1)
 if n!=1:raise ValueError('color not found: '+key)
(CO/'color.xml').write_text(color_src,encoding='utf-8')

menu_file=SRC/'widget/win_t2_main_menu.xml'
xml=menu_file.read_text(encoding='utf-8')
# retain semantic bindings/layout; merely brighten gray-colored helper labels
xml=xml.replace('#CEE8FF','#EDF5FF')
(WIDGET/'win_t2_main_menu.xml').write_text(xml,encoding='utf-8')

# Preview uses the exact modified BMP images and original menu dimensions but is NOT a device screenshot.
preview=Image.new('RGB',(1024,576))
d=ImageDraw.Draw(preview)
for y in range(576):
 t=y/575
 d.line((0,y,1023,y),fill=(int(7+10*t),int(12+17*t),int(25+28*t)))
# decorative background subtle blobs rendered offline
layer=Image.new('RGBA',(1024,576))
dg=ImageDraw.Draw(layer)
dg.ellipse((630,-280,1220,310),fill=(30,107,159,105))
dg.ellipse((-350,260,330,950),fill=(60,78,164,88))
layer=layer.filter(ImageFilter.GaussianBlur(95))
preview=Image.alpha_composite(preview.convert('RGBA'),layer)
d=ImageDraw.Draw(preview)
d.rounded_rectangle((75,32,949,552),radius=27,fill=(19,28,45,238),outline=(80,100,128,220),width=2)
d.rounded_rectangle((81,38,943,177),radius=20,fill=(43,61,80,220))
for i,k in enumerate(NAMES):
 im=Image.open(DO/f'T2_icon_{k}_{"focus" if k=="system" else "unfocus"}.bmp').convert('RGB')
 preview.paste(im,(120+112*i,34))
d=ImageDraw.Draw(preview)
ft=ImageFont.truetype(FONTB,28)
fm=ImageFont.truetype(FONT,20)
fs=ImageFont.truetype(FONT,16)
d.text((115,189),'Настройки',font=ft,fill='#f4faff')
rows=['Информация о приставке','Настройки изображения','Язык и регион','Сетевые параметры','Обновление ПО','Заводские настройки']
for i,x in enumerate(rows):
 y=237+i*41
 if i==0:
  d.rounded_rectangle((112,y,912,y+37),radius=12,fill=(45,90,120,255),outline=(115,201,245,255),width=2)
 d.text((136,y+7),x,font=fm,fill='#f1f8ff' if i==0 else '#ced9eb')
 d.text((876,y+5),'›',font=fm,fill='#a8c7dc')
d.line((104,507,919,507),fill=(84,106,134),width=1)
d.text((120,520),'ESC  Назад',font=fs,fill='#a7bcd5')
d.text((430,520),'OK  Подтвердить',font=fs,fill='#a7bcd5')
d.text((810,520),'ROMsat Glass · preview',font=fs,fill='#a7bcd5',anchor='lt')
preview.convert('RGB').save(BASE/'liquid_glass_preview.png',quality=95)

readme='''# ROMSAT T8020HD — Liquid Glass theme alpha 0.1\n\nЭТО НЕ ПРОШИВКА. НЕ ЗАГРУЖАТЬ ZIP НА ПРИСТАВКУ!\n\nЭто тестовый пакет изменённых ресурсов, полученных из предоставленной пользователем оригинальной прошивки.\n\n## Содержимое\n- dvb/theme/image/image_T2/mainmenu/: 14 иконок (7 разделов, 2 состояния)\n- dvb/theme/image/image_T2/BUTTON/T2_button_blue1000.bmp: фокус списка\n- dvb/theme/color/color.xml: нейтральная тёмная палитра и голубые акценты\n- dvb/theme/widget/win_t2_main_menu.xml: светлые подписи\n\n## Совместимость\n- Оригинальное разрешение иконок: 112x137.\n- BMP: 16-бит RGB565, BI_BITFIELDS, сохранены размеры файлов и заголовки.\n- Исходная компоновка главного меню, имена элементов, горячие клавиши и обработчики оставлены.\n- XML разметка протестирована парсером; функциональность на устройстве НЕ проверена.\n- Скриншот `liquid_glass_preview.png` является графическим МАКЕТОМ, а не фактической фотографией приставки.\n\n## Для дальнейшей сборки\nНужен безопасный репакер GX / cramfs + проверка полного образа, CRC разделов, серийных данных и способ восстановления через UART/программатор.\nНельзя прошивать неподтверждённый файл.\n'''
(OUT/'README_RU.txt').write_text(readme,encoding='utf-8')
# Verify XML and files
import xml.etree.ElementTree as ET
ET.parse(CO/'color.xml');ET.parse(WIDGET/'win_t2_main_menu.xml')
for bmp in list(DO.glob('*.bmp'))+list(BO.glob('*.bmp')):
 im=Image.open(bmp); im.verify()

zpath=BASE/'romsat_liquid_glass_theme_alpha.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in OUT.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(OUT))
print('Theme created:',zpath, zpath.stat().st_size,'files:',len(list(OUT.rglob('*'))))
print('preview:',BASE/'liquid_glass_preview.png')
