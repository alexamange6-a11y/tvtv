#!/usr/bin/env python3
"""Experimental *real XML layout* patch for ROMSAT T8020HD, NOT FLASHABLE.
The XML preserves runtime widget names, signals, number of tabs, and list handler.
"""
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
import xml.etree.ElementTree as ET
import struct, shutil, zipfile, re, json
ROOT=Path('/mnt/data/romsat_analysis')
THEME=ROOT/'extracted/cramfs/dvb/theme'
SRC_IMG=Path('/mnt/data/Жидкий стеклянный интерфейс ТВ-приставки(1).png')
OUT=ROOT/'romsat_appletv_layout_v1'
if OUT.exists():shutil.rmtree(OUT)
(OUT/'dvb/theme/widget').mkdir(parents=True)
IMAGES=OUT/'dvb/theme/image/image_T2/mainmenu'
IMAGES.mkdir(parents=True)
(OUT/'dvb/theme/color').mkdir(parents=True)
IMG=THEME/'image/image_T2/mainmenu'
SC=3
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font=lambda size,bold=False:ImageFont.truetype(FONTB if bold else FONT,size)

# Encode conventional uncompressed RGB565 BMP with BI_BITFIELDS and no alpha.
def rgb565_save(im,path):
 im=im.convert('RGB');w,h=im.size
 stride=((w*2+3)//4)*4
 pix=bytearray(stride*h)
 for y in range(h):
  yy=h-1-y
  for x in range(w):
   r,g,b=im.getpixel((x,yy))
   struct.pack_into('<H',pix,y*stride+x*2,((r>>3)<<11)|((g>>2)<<5)|(b>>3))
 offset=14+40+12
 header=struct.pack('<2sIHHI',b'BM',offset+len(pix),0,0,offset)
 dib=struct.pack('<IiiHHIIiiII',40,w,h,1,16,3,len(pix),2835,2835,0,0)
 path.write_bytes(header+dib+struct.pack('<III',0xF800,0x07E0,0x001F)+pix)
 assert Image.open(path).size==(w,h)

# Make background exactly 1024 x 576, with mountain source imagery from the user's supplied reference.
w,h=1024,576
bg=Image.new('RGB',(w*SC,h*SC))
d=ImageDraw.Draw(bg)
for y in range(h*SC):
 t=y/(h*SC)
 d.line((0,y,w*SC,y),fill=(int(9+9*t),int(15+14*t),int(32+27*t)))
# Ambient colored gradients / spheres
color=Image.new('RGBA',bg.size,(0,0,0,0));cl=ImageDraw.Draw(color)
cl.ellipse((-180*SC,270*SC,450*SC,730*SC),fill=(99,78,193,100))
cl.ellipse((720*SC,-300*SC,1300*SC,360*SC),fill=(51,107,213,125))
cl.ellipse((250*SC,160*SC,710*SC,700*SC),fill=(30,74,168,70))
color=color.filter(ImageFilter.GaussianBlur(84*SC))
bg=Image.alpha_composite(bg.convert('RGBA'),color)
d=ImageDraw.Draw(bg)
def RR(b,r,fill,outline=None,width=1):
 d.rounded_rectangle(tuple(int(v*SC) for v in b),radius=r*SC,fill=fill,outline=outline,width=width*SC)
def TXT(pt,s,size,col,bold=False):
 d.text((pt[0]*SC,pt[1]*SC),s,font=font(size*SC,bold),fill=col)
# brand, top elements, with no fake live time or Wi-Fi status
TXT((50,15),'ROMSAT',21,'#F4F7FF',True)
TXT((169,18),'T8020HD',17,'#BAC7DE')
RR((849,12,975,42),17,(31,40,62,230),(82,94,127,210))
TXT((867,19),'ГЛАВНАЯ',12,'#DCEAFF',True)
# Hero background mountain region, adapted from user's reference without screenshot's labels.
ref=Image.open(SRC_IMG).convert('RGB')
# mountain skyline from reference 760..1570, y150..470; avoids original textual area.
mount=ref.crop((720,150,1550,465)).resize((935*SC,186*SC),Image.Resampling.LANCZOS).convert('RGBA')
mask=Image.new('L',mount.size,0);md=ImageDraw.Draw(mask)
md.rounded_rectangle((0,0,mount.width-1,mount.height-1),radius=26*SC,fill=255)
bg.alpha_composite(Image.new('RGBA',bg.size,(0,0,0,0)))
layer=Image.new('RGBA',bg.size,(0,0,0,0));layer.paste(mount,(45*SC,55*SC),mask)
bg=Image.alpha_composite(bg,layer)
# overlay left-to-right shading so text stays legible
veil=Image.new('RGBA',bg.size,(0,0,0,0));v=ImageDraw.Draw(veil)
for x in range(45*SC,982*SC,2):
 t=(x-45*SC)/(937*SC)
 a=int(205*(1-t)**2+25)
 v.line((x,55*SC,x,241*SC),fill=(11,23,46,a),width=2)
bg=Image.alpha_composite(bg,veil);d=ImageDraw.Draw(bg)
RR((45,55,979,241),25,None,(133,154,202,220),1)
TXT((82,82),'ТВОЯ ПРИСТАВКА',11,'#B8CDEA',True)
TXT((82,106),'Телевидение',30,'#F5F8FF',True)
TXT((82,143),'и развлечения',26,'#F5F8FF',True)
TXT((83,188),'Выберите раздел с помощью пульта',13,'#B7C5DC')
RR((796,203,943,229),12,(52,66,96,185),(119,141,175,170),1)
TXT((809,207),'OK  Открыть',12,'#F6F9FF')
# subtle row label and bottom section background (functional list draws over this)
TXT((53,256),'РАЗДЕЛЫ',11,'#BACAE1',True)
RR((44,399,980,538),17,(19,31,51,219),(89,107,143,120),1)
TXT((61,409),'ПУНКТЫ ВЫБРАННОГО РАЗДЕЛА',10,'#BBCDE7',True)
RR((44,544,980,568),11,(30,40,62,230),(73,89,115,125))
bg=bg.convert('RGB').resize((1024,576),Image.Resampling.LANCZOS)
BG=IMAGES/'T2_appletv_home_background.bmp'
rgb565_save(bg,BG)

# Tiles correspond to the same 7 function categories as the original firmware.
# The look changes; names and event handlers in the firmware are left intact.
labels={'program':'ТВ','pic':'Экран','search':'Поиск','time':'Время','option':'Опции','system':'Система','usb':'USB'}
def tile(key,selected=False):
 s=SC;W,H=112*s,137*s
 im=Image.new('RGBA',(W,H),(0,0,0,0))
 # color key magenta: original system uses magenta as transparency. For safety, flat dark background covers full tile.
 ds=ImageDraw.Draw(im)
 for y in range(H):
  t=y/(H-1)
  ds.line((0,y,W,y),fill=(int(33+13*t),int(46+10*t),int(74+14*t),255))
 ds.rounded_rectangle((3*s,3*s,108*s,134*s),radius=20*s,
  fill=(68,83,129,255) if selected else (40,55,82,255),
  outline=(184,210,255,255) if selected else (90,112,152,255),width=(3 if selected else 1)*s)
 ds.rounded_rectangle((10*s,11*s,102*s,49*s),radius=15*s,fill=(112,140,206,100) if selected else (86,112,150,75))
 col=(249,252,255) if selected else (202,219,245)
 cx,cy=56,63
 def line(pts,width=3):ds.line([(int(a*s),int(b*s)) for a,b in pts],fill=col,width=width*s,joint='curve')
 def ell(bb,width=3,fill=None):ds.ellipse(tuple(int(q*s) for q in bb),outline=col if fill is None else None,fill=fill,width=width*s)
 def rrect(bb,r=5,width=3):ds.rounded_rectangle(tuple(int(q*s) for q in bb),radius=r*s,outline=col,width=width*s)
 if key=='program':
  rrect((33,47,79,78));line([(55,78),(55,83)],2);line([(41,84),(69,84)],2)
 elif key=='pic':
  rrect((34,44,79,80));ell((41,50,50,59),2);ds.polygon([(39*s,74*s),(49*s,63*s),(57*s,69*s),(67*s,57*s),(76*s,75*s)],fill=col)
 elif key=='search':
  ell((36,43,66,73),4);line([(64,71),(78,86)],4)
 elif key=='time':
  ell((34,43,78,87),3);line([(56,50),(56,65),(45,72)],3)
 elif key=='option':
  ell((34,43,78,87),3);ell((47,43,65,87),2);line([(35,64),(77,64)],2);line([(39,52),(74,52)],1);line([(39,77),(74,77)],1)
 elif key=='system':
  import math
  pts=[]
  for i in range(24):
   a=i*math.pi/12;rr=22 if i%3==0 else 17
   pts.append(((56+rr*math.cos(a))*s,(65+rr*math.sin(a))*s))
  ds.polygon(pts,fill=col);ell((49,58,63,72),2,fill=(63,81,125,255) if selected else (40,55,82,255))
 elif key=='usb':
  line([(56,82),(56,49)],3);line([(56,66),(42,55),(42,49)],3);line([(56,73),(71,59),(71,51)],3);ds.polygon([(71*s,44*s),(65*s,52*s),(77*s,52*s)],fill=col);ell((51,78,61,88),2)
 txt=labels[key]
 f=font((14 if len(txt)<7 else 12)*s,True if selected else False)
 box=ds.textbbox((0,0),txt,font=f)
 ds.text(((W-(box[2]-box[0]))/2,99*s),txt,font=f,fill=(248,251,255) if selected else (228,236,250))
 if selected:ds.rounded_rectangle((34*s,126*s,78*s,129*s),radius=1*s,fill=(191,223,255))
 return im.convert('RGB').resize((112,137),Image.Resampling.LANCZOS)
for k in labels:
 for kind in ('focus','unfocus'):
  rgb565_save(tile(k,kind=='focus'),IMAGES/f'T2_icon_{k}_{kind}.bmp')
# Important: firmware resolves bitmap ID via image.xml registry, not by file name alone.
registry_source=THEME/'image/image.xml'
registry=ET.parse(registry_source)
registry_root=registry.getroot()
assert not any(entry.get('id')==BG.name for entry in registry_root.findall('image'))
reg_entry=ET.SubElement(registry_root,'image',{'id':BG.name})
reg_entry.text='image_T2/mainmenu/'+BG.name
registry_out=OUT/'dvb/theme/image/image.xml'
registry.write(registry_out,encoding='ISO-8859-1',xml_declaration=True)
ET.parse(registry_out)
# Patch the original layout with the *same exact widget names and handler signal names*.
xmlpath=THEME/'widget/win_t2_main_menu.xml'
tree=ET.parse(xmlpath);root=tree.getroot()
widgets={w.attrib.get('name'):w for w in root.findall('children/widget')}
def rect(name,xywh):
 w=widgets[name]
 t=w.find('./property/rect')
 assert t is not None,name
 t.text='['+','.join(str(v) for v in xywh)+']'
# Background: replace old multi-sliced frame with complete, layout-designed home surface.
w=widgets['win_t2_main_menu_background'];p=w.find('property')
p.find('rect').text='[0,0,1024,576]';p.find('mode').text='single';p.find('img').text=BG.name
# Remove multi-image attributes so loader does not try to combine old skins in single mode.
for child in list(p):
 if child.tag in ('lt_img','rt_img','lb_img','rb_img','l_img','r_img','t_img','b_img'):p.remove(child)
# Original bottom/footer frame and optional overlays could cover home screen; suppress only decor.
for k in ('win_t2_main_menu_background_up','win_t2_main_menu_background_down','win_t2_main_menu_background_down2'):
 # There are 2 same-named background_down widgets! Hide all matching decor except fullscreen.
 for widget in root.findall('./children/widget'):
  if widget.attrib.get('name')==k:
   prop=widget.find('property');state=prop.find('state')
   if state is None:state=ET.SubElement(prop,'state')
   state.text='hide'
# The icons are navigable functional categories and remain the same seven IDs as stock.
names=['program','picture','search','time','option','system','usb']
for i,k in enumerate(names):
 rect('win_t2_main_menu_title_'+k,(55+i*132,268,112,137))
# Move title and list beneath tiles; retain original list width, item size and C callbacks.
rect('txt_t2_main_menu_title',(64,430,790,26))
rect('win_t2_main_menu_list',(112,460,800,75))
# Footer controls condensed but visible; leave click/key handlers unchanged.
rect('win_t2_main_menu_logo',(55,528,96,39))
# Header already carries device name; avoid duplicate logo obscuring footer.
logo_prop=widgets['win_t2_main_menu_logo'].find('property')
logo_state=logo_prop.find('state')
if logo_state is None:logo_state=ET.SubElement(logo_prop,'state')
logo_state.text='hide'
rect('win_t2_main_menu_exit_btn',(218,545,46,25))
rect('win_t2_main_menu_return_txt',(267,545,150,25))
rect('win_t2_main_menu_ok_btn',(458,545,46,25))
rect('win_t2_main_menu_ok_txt',(509,545,150,25))
rect('win_t2_main_menu_arrow_img',(903,540,34,33))
rect('text_main_menu_active',(616,546,270,23))
# Match actual dark palette: keep existing runtime keys.
colors=(THEME/'color/color.xml').read_text(encoding='utf-8')
replace={'text_focus_color':'#FFFFFF','text_tag_color':'#BFD5FB','text_golden_color':'#9FC7FA','window_bg_color':'#132039','window_top_color':'#142139','window_bot_color':'#142139','default_color':'#8295B4'}
for key,newcol in replace.items():
 regex=r'(<color\s+name="'+re.escape(key)+r'"\s*>\s*)#[0-9A-Fa-f]{6}(\s*</color>)'
 colors,n=re.subn(regex,lambda m:m.group(1)+newcol+m.group(2),colors,count=1)
 if n!=1:raise RuntimeError('No color: '+key)
(OUT/'dvb/theme/color/color.xml').write_text(colors,encoding='utf-8')
# Validate that widgets/function references were not removed or renamed.
old=ET.parse(xmlpath).getroot()
newroot=root
assert [(v.attrib.get('name'),v.attrib.get('class')) for v in old.findall('./children/widget')]==[(v.attrib.get('name'),v.attrib.get('class')) for v in newroot.findall('./children/widget')]
assert [ET.tostring(v) for v in old.iter('signal')]==[ET.tostring(v) for v in newroot.iter('signal')]
for w in newroot.findall('./children/widget'):
 v=w.find('./property/rect')
 if v is None:continue
 try:
  x,y,width,height=(int(s) for s in v.text.strip('[]').split(','))
  assert x>=0 and y>=0 and x+width<=1024 and y+height<=576,(w.attrib['name'],v.text)
 except Exception as e:raise RuntimeError(f'Invalid geometry {w.attrib.get("name")} {v.text}: {e}')
# Retain XML declaration, make output diffs easy to read.
ET.indent(tree,space='    ')
patched=OUT/'dvb/theme/widget/win_t2_main_menu.xml'
tree.write(patched,encoding='UTF-8',xml_declaration=True)
ET.parse(patched)
# Preview = exact background and real modified tile files plus indicative list content; not a runtime screenshot.
prev=Image.open(BG).convert('RGB')
for i,k in enumerate(labels):
 bmp=Image.open(IMAGES/f'T2_icon_{k}_{"focus" if k=="program" else "unfocus"}.bmp').convert('RGB')
 prev.paste(bmp,(55+i*132,268))
pr=ImageDraw.Draw(prev)
pr.text((64,434),'Телевидение',font=font(19,True),fill='#EFF5FF')
pr.rounded_rectangle((111,462,910,497),radius=8,fill=(70,95,143),outline=(137,176,237),width=2)
pr.text((130,469),'Список каналов',font=font(16),fill='#FFFFFF')
pr.text((130,505),'Редактирование каналов',font=font(15),fill='#D5E4FD')
pr.text((266,546),'Назад',font=font(12),fill='#BACDE8')
pr.text((505,546),'OK — выбрать',font=font(12),fill='#BACDE8')
preview_path=ROOT/'romsat_appletv_layout_preview.png'
prev.save(preview_path)
readme='''ROMSAT T8020HD — Apple-TV-like layout: XML layout patch (experimental)\n\nЭТО НЕ ПРОШИВКА. НЕ УСТАНАВЛИВАТЬ ZIP НА ПРИСТАВКУ!\n\nЭто набор реальных файлов XML и BMP для замены файлов в cramfs при будущей перепаковке.\nОн изменяет КООРДИНАТЫ и компоновку существующего главного меню.
- image/image.xml: зарегистрировано имя нового BMP-фона;\n- большая информационная панель сверху;\n- семь крупных плиток существующих разделов по горизонтали;\n- список пунктов текущего раздела снизу;\n- упрощённая нижняя панель управления.\n\nЧто осталось без изменений:\n- имена всех виджетов, классы виджетов и сигналы/обработчики;\n- порядок семи разделов;\n- пункты меню формируются оригинальным программным кодом;\n- размеры элементов списка и ширина списка (800 px) не изменены.\n\nВАЖНЫЕ ОГРАНИЧЕНИЯ:\n- YouTube, MEGOGO, IPTV не добавлены в главное меню как новые кнопки.\n- Список 'Недавно открыто' нельзя получить одним XML-патчем: нужна модификация логики прошивки.\n- Новый главный фон BMP 1024x576 (RGB565) и две строки меню потребуют аппаратного теста.\n- Возможно, прошивка игнорирует любые незнакомые имена ресурсов или не поддерживает полноэкранные BMP.\n- Никакого безопасного полного образа для прошивки пока нет; прошивальщик/проверка CRC и восстановление не проверены.\n- Превью — модель ожидаемого расположения, НЕ снимок реального экрана.\n- Заголовок и элементы списка в реальной приставке динамические, а в превью показаны примеры.\n\nПроверки:\n- XML парсится, все существующие имена виджетов и сигналы совпадают с исходными;\n- все перемещённые элементы в пределах 1024x576;\n- все BMP декодируются как RGB565, размеры плиток 112x137.\n'''
(OUT/'README_RU.txt').write_text(readme,encoding='utf-8')
with zipfile.ZipFile(ROOT/'romsat_appletv_layout_patch_not_flashable.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in OUT.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(OUT))
print('PATCH:',ROOT/'romsat_appletv_layout_patch_not_flashable.zip')
print('PREVIEW:',preview_path)
print('BG bytes:',BG.stat().st_size,'ZIP bytes:',(ROOT/'romsat_appletv_layout_patch_not_flashable.zip').stat().st_size)
print('Changed XML positions:', [(n,widgets[n].find('./property/rect').text) for n in ['win_t2_main_menu_title_program','win_t2_main_menu_list','txt_t2_main_menu_title']])
