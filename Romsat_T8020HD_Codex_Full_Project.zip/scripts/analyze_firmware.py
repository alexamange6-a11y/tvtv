#!/usr/bin/env python3
"""Read-only extractor for the known ROMSAT GX3235S firmware: ROMFS and cramfs."""
from pathlib import Path
import struct, zlib, lzma, hashlib, json, collections
SRC=Path(__file__).parent/'30303_303_T8020HD_1_220_GX3235S_G10B_IR22_CID3_R561_flash_2408021509.bin'
OUT=Path(__file__).parent/'extracted'; OUT.mkdir(exist_ok=True)
b=SRC.read_bytes()
fsstart=0x2c0000
fs=b[fsstart:fsstart+struct.unpack_from('<I',b,fsstart+4)[0]]
assert fs[:4]==b'\x45\x3d\xcd\x28'
entries=[]; errors=[]
def read_inode(off):
 a,c,d=struct.unpack_from('<III',fs,off)
 return {'mode': a&0xffff,'uid':a>>16, 'size':c&0xffffff,'gid':c>>24, 'offset':(d>>6)*4,'namelen':(d&0x3f)*4}
def extract_dir(inode,path,depth=0):
 if depth>20:raise ValueError('depth')
 off=inode['offset']; end=off+inode['size']
 if end>len(fs): raise ValueError((off,end))
 while off<end:
  node=read_inode(off); raw=fs[off+12:off+12+node['namelen']]
  name=raw.split(b'\x00',1)[0].decode('utf-8','replace')
  off+=12+node['namelen']
  if not name or name in ('.','..') or '/' in name:continue
  fp=path/name
  node['path']=str(fp.relative_to(OUT))
  entries.append(node)
  mode=node['mode']&0xf000
  if mode==0x4000:
   fp.mkdir(exist_ok=True,parents=True)
   extract_dir(node,fp,depth+1)
  elif mode==0x8000:
   size=node['size']; count=(size+4095)//4096
   ptr=node['offset']
   try:
    pointers=list(struct.unpack_from('<'+'I'*count,fs,ptr))
    start=ptr+count*4; result=bytearray()
    for x in pointers:
     if x<start or x>len(fs):raise ValueError(f'bad compressed pointer {x:x} start {start:x}')
     chunk=fs[start:x]
     result+= zlib.decompress(chunk) if chunk else b'\0'*4096
     start=x
    if len(result)<size:raise ValueError('short decompression')
    fp.parent.mkdir(parents=True,exist_ok=True);fp.write_bytes(result[:size])
    node['extracted']=True
   except Exception as exc:
    node['error']=str(exc); errors.append((node['path'],str(exc)))
  else:
   node['special']=True
root=read_inode(0x40)
extract_dir(root,OUT/'cramfs')
print('cramfs root:',root,'entries:',len(entries),'errors:',errors[:30])
(OUT/'cramfs_index.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False))
for x in entries:
 print('%-8s %8d %08x %s %s'% ('dir' if x['mode']&0xf000==0x4000 else 'file',x['size'],x['offset'],x['path'], 'ERROR' if x.get('error') else ''))
# ROMFS root and first file: manually read valid big-endian ROMFS header and inode names
r=b[0x30000:0x30000+0x280950]
assert r[:8]==b'-rom1fs-'
print('ROMFS bytes',hex(struct.unpack_from('>I',r,8)[0]))
# lzma file starts 0x80 within romfs, compressed size from file header 0x68 (ROMFS file inode)
compressed_size=struct.unpack_from('>I',r,0x68)[0]
print('ROMFS ecos lzma size',hex(compressed_size))
if 0<compressed_size<len(r):
 payload=r[0x80:0x80+compressed_size]
 (OUT/'ecos.bin.lzma').write_bytes(payload)
 try:
  raw=lzma.decompress(payload,format=lzma.FORMAT_ALONE)
  (OUT/'ecos.bin').write_bytes(raw);print('ecos decompressed',len(raw))
 except Exception as e:print('ecos lzma error',e)
