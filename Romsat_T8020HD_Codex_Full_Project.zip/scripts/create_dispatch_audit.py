from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
p=Path('/mnt/data/romsat_analysis'); root=p/'extracted/cramfs/dvb/theme/widget'; blob=(p/'extracted/ecos.bin').read_bytes()
checks={
 'main-menu-create':('win_t2_main_menu.xml','win_t2_main_menu_create'),
 'main-menu-key':('win_t2_main_menu.xml','win_t2_main_menu_keypress'),
 'list-key':('win_t2_main_menu.xml','list_t2_main_menu_keypress'),
 'list-data':('win_t2_main_menu.xml','list_t2_main_menu_getdata'),
 'iptv-entry':('wnd_iptv.xml','app_iptv_create'),
 'network-video-entry':('wnd_apps_netvideo.xml','app_netvideo_create')}
rows=[]
for k,(file,symbol) in checks.items():
 f=root/file
 txt=f.read_text(errors='replace') if f.exists() else ''
 hits=[]; off=0
 while True:
  idx=blob.find(symbol.encode(),off)
  if idx<0:break
  hits.append({'hex':hex(idx),'decimal':idx});off=idx+1
 rows.append({'id':k,'xml_file':str(f.relative_to(p/'extracted/cramfs')),'xml_exists':f.exists(),'xml_mentions_symbol':symbol in txt,'symbol':symbol,'string_offsets':hits,'verified_entrypoint':False})
report={'firmware_sha256':hashlib.sha256((p/'30303_303_T8020HD_1_220_GX3235S_G10B_IR22_CID3_R561_flash_2408021509.bin').read_bytes()).hexdigest(),'ecos_unpacked_sha256':hashlib.sha256(blob).hexdigest(),'architecture_family':'GX3235S eCos MIPS32 (from chipset documentation, not executable disassembly)','analysis':'Strings in binary do not establish code locations or callable interfaces','symbol_audit':rows,'feature_status':{'YouTube':'strings only; binary entrypoint unverified','MEGOGO':'strings only; binary entrypoint unverified','IPTV':'widget and app-related strings exist; direct launch unverified','Recent':'no native implementation verified'},'next_requirements':['determine eCos image load address and executable code ranges','identify actual MIPS32 function bodies and window manager API','prove dispatch from key handler to window API','implement and test history persistence','repack firmware and validate update format plus recovery path']}
out=p/'romsat_dispatch_audit';out.mkdir(exist_ok=True)
(out/'dispatch_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
text='''# Romsat T8020HD — исследование запуска приложений\n\nЭтот пакет НЕ содержит прошивку и НЕ меняет машинный код приставки.\n\nРеально подтверждено: XML главного меню вызывает `win_t2_main_menu_keypress`; список имеет собственный `list_t2_main_menu_keypress`. В распакованном ecos.bin найдены строковые имена обработчиков. Наличие строки не означает, что известен адрес функции, сигнатура или безопасный способ её вызвать.\n\nИнтерфейс можно переставлять XML-файлами из предыдущего патча. Чтобы из плиток YouTube/MEGOGO/IPTV действительно открывались приложения, надо найти MIPS-обработчик и способ переключения окон. Список «Недавно открыто» потребует состояния/хранилища, а не только оформления.\n\nИзменения в `ecos.bin` НЕ внесены: нельзя гарантировать работу и сохранность приставки без дизассемблирования, сборки с корректными контрольными суммами и плана восстановления через SPI/UART.\n\nСм. `dispatch_audit.json` для точных смещений строк и SHA256 оригинала.\n'''
(out/'README.md').write_text(text,encoding='utf-8')
with zipfile.ZipFile(p/'romsat_dispatch_audit.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in out.iterdir(): z.write(f,f.name)
print(json.dumps([(r['id'],r['xml_exists'],r['xml_mentions_symbol'],r['string_offsets']) for r in rows],ensure_ascii=False,indent=2));print(p/'romsat_dispatch_audit.zip')
