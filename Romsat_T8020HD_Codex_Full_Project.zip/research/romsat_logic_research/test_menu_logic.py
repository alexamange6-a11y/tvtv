from menu_logic_prototype import HomeMenu
def test_navigation():
 m=HomeMenu();assert m.key("LEFT")[1]==0
 assert m.key("RIGHT")[1]==1
 assert m.key("OK")==('REQUEST_OPEN','MEGOGO')
 assert list(m.recent)==['MEGOGO']
 m.key('UP');m.key('RIGHT');assert m.key('OK')==('REQUEST_OPEN','IPTV')
 assert list(m.recent)==['IPTV','MEGOGO']
if __name__=='__main__':test_navigation();print('prototype tests OK')
