"""HOST-SIDE REFERENCE MODEL ONLY; NOT EXECUTABLE ON GX3235S.
Illustrates input handling, six tiles and recent history independently of firmware APIs.
"""
from collections import deque
TILES=("YouTube","MEGOGO","IPTV","Кино","Медиа","Настройки")
class HomeMenu:
    def __init__(self):
        self.focus=0
        self.recent=deque(maxlen=3)
        self.area="tiles"
    def key(self, name):
        if name=="LEFT" and self.area=="tiles": self.focus=max(0,self.focus-1)
        elif name=="RIGHT" and self.area=="tiles": self.focus=min(len(TILES)-1,self.focus+1)
        elif name=="DOWN": self.area="recent" if self.recent else "tiles"
        elif name=="UP": self.area="tiles"
        elif name=="OK":
            item=TILES[self.focus] if self.area=="tiles" else self.recent[0]
            if item in self.recent:self.recent.remove(item)
            self.recent.appendleft(item)
            return ("REQUEST_OPEN",item)
        elif name=="BACK":return ("REQUEST_BACK",None)
        return ("FOCUS",self.focus,self.area)
